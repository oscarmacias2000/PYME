const cron = require('node-cron');
const config = require('../config');
const sheets = require('../services/sheets');
const gmail = require('../services/gmail');
const whatsapp = require('../services/whatsapp');
const { filasAXlsxBuffer } = require('../services/xlsx');

// Equivalente a "Filtrar hoy y armar resumen": deja solo las filas de la fecha de hoy
// y calcula los totales.
function filtrarHoyYArmarResumen(filas) {
  const hoy = new Date().toISOString().slice(0, 10);
  const deHoy = filas.filter((r) => String(r.Fecha || '').slice(0, 10) === hoy);

  let totalJornaleros = 0;
  let totalNomina = 0;
  const lineas = deHoy.map((r) => {
    totalJornaleros += Number(r['N° Jornaleros']) || 0;
    totalNomina += Number(r['Nómina Total']) || 0;
    return `- ${r.Campo || '-'} / ${r.Lote || '-'} - ${r.Actividad || '-'} (${r['N° Jornaleros'] || 0} jornaleros, resp. ${r.Responsable || '-'})`;
  });

  const cuerpoTexto =
    `Resumen de Actividades Agricolas - ${hoy}\n\n` +
    `Actividades registradas: ${deHoy.length}\n` +
    `Total jornaleros: ${totalJornaleros}\n` +
    `Nomina total estimada: $${totalNomina.toFixed(2)}\n\n` +
    (lineas.join('\n') || 'Sin registros para hoy.');

  const filasHtml = deHoy
    .map(
      (r) =>
        `<tr><td>${r.Campo || ''}</td><td>${r.Lote || ''}</td><td>${r.Actividad || ''}</td>` +
        `<td>${r.Responsable || ''}</td><td>${r['N° Jornaleros'] || ''}</td><td>${r['Nómina Total'] || ''}</td></tr>`
    )
    .join('');
  const cuerpoHtml =
    `<h2>Resumen de Actividades Agricolas - ${hoy}</h2>` +
    `<p>Actividades registradas: ${deHoy.length}<br>Total jornaleros: ${totalJornaleros}<br>Nomina total estimada: $${totalNomina.toFixed(2)}</p>` +
    `<table border="1" cellpadding="6" cellspacing="0"><tr><th>Campo</th><th>Lote</th><th>Actividad</th><th>Responsable</th><th>Jornaleros</th><th>Nomina</th></tr>${filasHtml}</table>`;

  return { asunto: `Resumen diario de actividades agricolas - ${hoy}`, cuerpoTexto, cuerpoHtml, filasDeHoy: deHoy, hoy };
}

async function ejecutarResumenDiario() {
  console.log('[resumen diario] generando...');
  const filas = await sheets.leerActividadesDiarias();
  const { asunto, cuerpoTexto, cuerpoHtml, filasDeHoy, hoy } = filtrarHoyYArmarResumen(filas);

  // Correo con Excel adjunto (equivalente a "Code in JavaScript" -> "Convert to File" -> "Enviar resumen por correo").
  const filasParaExcel = filasDeHoy.length > 0
    ? filasDeHoy
    : [{ Fecha: hoy, Campo: '', Lote: '', Actividad: '', Responsable: '', 'N° Jornaleros': '', 'Procedencia / Cuadrilla': '', 'Recursos / Maquinaria': '', 'Costo por Jornal': '', 'Nómina Total': '', Observaciones: 'Sin registros para hoy' }];
  try {
    const buffer = await filasAXlsxBuffer(filasParaExcel, 'Actividades');
    await gmail.enviarCorreoConAdjunto({
      asunto,
      html: cuerpoHtml,
      texto: cuerpoTexto,
      adjuntoBuffer: buffer,
      nombreArchivo: `resumen-${hoy}.xlsx`,
    });
    console.log('[resumen diario] correo enviado');
  } catch (e) {
    console.error('[resumen diario] error enviando correo:', e.message);
  }

  // Resumen por WhatsApp en paralelo (equivalente a "WhatsApp: enviar resumen").
  if (config.whatsapp.resumenPhoneNumberId && config.whatsapp.resumenNumeroDestino) {
    try {
      await whatsapp.enviarTexto(config.whatsapp.resumenPhoneNumberId, config.whatsapp.resumenNumeroDestino, cuerpoTexto);
      console.log('[resumen diario] WhatsApp enviado');
    } catch (e) {
      console.error('[resumen diario] error enviando WhatsApp:', e.response?.data || e.message);
    }
  }
}

function programarResumenDiario() {
  // Por defecto "0 20 * * *" (8:00 PM) en la zona horaria configurada (America/Mazatlan).
  cron.schedule(config.resumenCron, ejecutarResumenDiario, { timezone: config.timezone });
  console.log(`[resumen diario] programado con cron "${config.resumenCron}" (${config.timezone})`);
}

module.exports = { programarResumenDiario, ejecutarResumenDiario };
