require('dotenv').config();

function req(name, fallback = '') {
  return process.env[name] !== undefined ? process.env[name] : fallback;
}

module.exports = {
  port: Number(req('PORT', 3000)),
  timezone: req('TIMEZONE', 'America/Mazatlan'),
  resumenCron: req('RESUMEN_CRON', '0 20 * * *'),

  gemini: {
    apiKey: req('GEMINI_API_KEY'),
    model: req('GEMINI_MODEL', 'gemini-3.6-flash'),
  },

  google: {
    serviceAccountEmail: req('GOOGLE_SERVICE_ACCOUNT_EMAIL'),
    // Los .env casi siempre traen los saltos de linea como "\n" literales; hay que convertirlos.
    privateKey: req('GOOGLE_PRIVATE_KEY').replace(/\\n/g, '\n'),
    sheets: {
      reporteCampo: {
        id: req('SHEET_REPORTE_CAMPO_ID'),
        tab: req('SHEET_REPORTE_CAMPO_TAB', 'Rendimiento Diario Jornal'),
      },
      actividadesDiarias: {
        id: req('SHEET_ACTIVIDADES_ID'),
        tab: req('SHEET_ACTIVIDADES_TAB', 'Actividades Diarias'),
      },
    },
  },

  gmail: {
    user: req('GMAIL_USER'),
    appPassword: req('GMAIL_APP_PASSWORD'),
    correoDestino: req('CORREO_DESTINO'),
  },

  whatsapp: {
    token: req('WHATSAPP_TOKEN'),
    verifyToken: req('WHATSAPP_VERIFY_TOKEN', 'agroPYME2026secreto'),
    graphVersion: req('WHATSAPP_GRAPH_VERSION', 'v20.0'),
    resumenPhoneNumberId: req('WHATSAPP_RESUMEN_PHONE_NUMBER_ID'),
    resumenNumeroDestino: req('WHATSAPP_RESUMEN_NUMERO_DESTINO'),
  },
};
