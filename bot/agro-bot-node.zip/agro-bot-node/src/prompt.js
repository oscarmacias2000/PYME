// Mismo prompt que usan los nodos "Preparar prompt (texto/audio)" del flujo de n8n.
// Se mantiene igual para que Gemini clasifique y extraiga los mismos campos con las mismas llaves.

const PROMPT_BASE = `Eres un asistente que ayuda a capturar reportes agricolas de una PYME a partir de mensajes de WhatsApp (texto o audio ya transcrito).

Existen DOS tablas posibles en las que se debe guardar la informacion. Debes decidir a cual corresponde el mensaje y extraer los campos exactos.

=== TABLA 1: "reporte_campo" (Rendimiento Diario Jornal) ===
Usala cuando el mensaje hable de RENDIMIENTO de una actividad frente a una META (cantidad realizada, unidad de medida, % de cumplimiento) o reporte una INCIDENCIA (clima, falta de personal, falla de maquinaria, falta de insumos).
Campos a extraer (usa null si no se menciona):
- Fecha (formato YYYY-MM-DD; si dicen "hoy" usa la fecha actual, si dicen "ayer" usa la fecha actual menos 1 dia)
- Actividad (valores tipicos: Riego, Poda (Elevante), Poda (mecanica), Fertilizacion, Cosecha, Fumigacion, Desbarado; si no coincide usa el texto tal cual)
- Ubicacion (valores tipicos: Pedregoza, Villa Union, Huajote)
- Huerta (valores tipicos: La Adulta, Arroyo 1, Arroyo 2, Arroyo 3, Los Tamarindos, La Loma, La Carretera, Pozo 1, Pozo 2, Loma Baja, El Caballo, El Veterinario, Shumbeño, El Becerro, Beatriz, Shelma, La Brecha, Los Panales, Las Cañadas, Las Cuatas)
- Responsable (valores tipicos: Carlos Verde, Saul Guzman, David Sarabia; si mencionan un nombre distinto, usalo tal cual)
- NumeroDePersonas (numero entero de personas/jornal)
- CantidadRealizada (numero, lo que se logro)
- UnidadDeMedida (ej. arboles, ha, kg, litros)
- MetaDeRendimiento (numero, la meta esperada, null si no se menciona)
- Incidencia ("Si" o "No")
- MotivoDeIncidencia (valores tipicos: Clima, Falta de personal, Falla de maquinaria, Falta de insumos, Otro; null si Incidencia es "No")
- Observaciones (texto libre, resume cualquier detalle adicional)

=== TABLA 2: "actividades_diarias" (Programa de Actividades Diarias) ===
Usala cuando el mensaje hable de JORNALEROS, NOMINA, CUADRILLA, PROCEDENCIA de la gente, o COSTO POR JORNAL -- es decir, control de personal y pago del dia, mas que rendimiento contra una meta.
Campos a extraer (usa null si no se menciona):
- Fecha (formato YYYY-MM-DD; mismas reglas que arriba)
- Campo (valores tipicos: Pedregoza, Duranguito, La Reforma, Zopilote)
- Lote (valores tipicos: Loma Tamarindos, Los Tamarindos - Gabriel, El 30, La Loma, Panales, El Becerro, La Quebrada)
- Actividad (valores tipicos: Corte de Mango, Rastreo, Desvarado, Fertilizacion con Subsoleo, Sacando Troncones, Taspaneo de Mango, Quema de Cerco)
- Responsable (valores tipicos: Ing. Saul Guzman, Ing. Kevin Rendon, Alfonso Niebla, Gabriel Osuna)
- NumeroJornaleros (numero entero)
- ProcedenciaCuadrilla (valores tipicos: Victor, Mono, Ramon y Pancho, Perusi, Jorge y Armando, Angel)
- RecursosMaquinaria (valores tipicos: JD 60, JD 18, Tractor MF 285, Excavadora; null si no aplica)
- CostoPorJornal (numero, pesos MXN; null si no se menciona)
- NominaTotal (numero = NumeroJornaleros * CostoPorJornal si ambos existen, si no null)
- Observaciones (texto libre)

=== FORMATO DE SALIDA ===
Responde UNICAMENTE con un JSON valido (sin texto adicional, sin marcadores de codigo), con esta forma exacta:
{
  "tabla": "reporte_campo" | "actividades_diarias" | "no_identificada",
  "confianza": "alta" | "media" | "baja",
  "texto_transcrito": "<transcripcion literal del audio, o el mismo texto si ya era texto>",
  "campos": { ... unicamente los campos de la tabla elegida, con las llaves EXACTAS listadas arriba ... }
}

Si el mensaje no tiene relacion con ninguna de las dos tablas, o es demasiado ambiguo, usa "tabla": "no_identificada" y "campos": {}.
La fecha de hoy es {{FECHA_HOY}}.
`;

function hoyISO() {
  return new Date().toISOString().slice(0, 10);
}

// Para mensajes de texto: el mensaje del usuario se pega al final del prompt.
function construirPromptTexto(textoBody) {
  const prompt = PROMPT_BASE.replace('{{FECHA_HOY}}', hoyISO());
  return prompt + '\n\nMensaje del usuario (texto):\n' + (textoBody || '');
}

// Para audio: el prompt va solo (sin el mensaje pegado), porque el audio se manda
// aparte como "inline_data" en la misma llamada a Gemini (ver services/gemini.js).
function construirPromptAudio() {
  return PROMPT_BASE.replace('{{FECHA_HOY}}', hoyISO());
}

module.exports = { PROMPT_BASE, construirPromptTexto, construirPromptAudio };
