const { google } = require('googleapis');
const config = require('../config');

let sheetsClient = null;

function getClient() {
  if (sheetsClient) return sheetsClient;
  const auth = new google.auth.JWT({
    email: config.google.serviceAccountEmail,
    key: config.google.privateKey,
    scopes: ['https://www.googleapis.com/auth/spreadsheets'],
  });
  sheetsClient = google.sheets({ version: 'v4', auth });
  return sheetsClient;
}

// Encabezados exactos de cada hoja (mismo orden que los nodos "Guardar en ..." de n8n).
const COLUMNAS_REPORTE_CAMPO = [
  'Fecha', 'Actividad', 'Ubicacion', 'Huerta', 'Responsable', 'N° de Personas',
  'Cantidad Realizada', 'Unidad de Medida', 'Meta de Rendimiento (jornal)',
  '¿Incidencia?', 'Motivo de Incidencia', 'Observaciones', 'Reportado por',
];

const COLUMNAS_ACTIVIDADES = [
  'Fecha', 'Campo', 'Lote', 'Actividad', 'Responsable', 'N° Jornaleros',
  'Procedencia / Cuadrilla', 'Recursos / Maquinaria', 'Costo por Jornal',
  'Nómina Total', 'Observaciones', 'Reportado por',
];

const CAMPOS_A_COLUMNAS_REPORTE_CAMPO = {
  Fecha: 'Fecha', Actividad: 'Actividad', Ubicacion: 'Ubicacion', Huerta: 'Huerta',
  Responsable: 'Responsable', NumeroDePersonas: 'N° de Personas', CantidadRealizada: 'Cantidad Realizada',
  UnidadDeMedida: 'Unidad de Medida', MetaDeRendimiento: 'Meta de Rendimiento (jornal)',
  Incidencia: '¿Incidencia?', MotivoDeIncidencia: 'Motivo de Incidencia', Observaciones: 'Observaciones',
};

const CAMPOS_A_COLUMNAS_ACTIVIDADES = {
  Fecha: 'Fecha', Campo: 'Campo', Lote: 'Lote', Actividad: 'Actividad', Responsable: 'Responsable',
  NumeroJornaleros: 'N° Jornaleros', ProcedenciaCuadrilla: 'Procedencia / Cuadrilla',
  RecursosMaquinaria: 'Recursos / Maquinaria', CostoPorJornal: 'Costo por Jornal',
  NominaTotal: 'Nómina Total', Observaciones: 'Observaciones',
};

function configDeTabla(tabla) {
  if (tabla === 'reporte_campo') {
    return {
      ...config.google.sheets.reporteCampo,
      columnas: COLUMNAS_REPORTE_CAMPO,
      mapaCampos: CAMPOS_A_COLUMNAS_REPORTE_CAMPO,
    };
  }
  return {
    ...config.google.sheets.actividadesDiarias,
    columnas: COLUMNAS_ACTIVIDADES,
    mapaCampos: CAMPOS_A_COLUMNAS_ACTIVIDADES,
  };
}

// Agrega una fila nueva (equivalente al operation "append" de los nodos Google Sheets).
async function guardarFila(tabla, campos, reportadoPor) {
  const { id, tab, columnas, mapaCampos } = configDeTabla(tabla);
  const porColumna = {};
  Object.entries(mapaCampos).forEach(([campo, columna]) => {
    porColumna[columna] = campos?.[campo] ?? '';
  });
  porColumna['Reportado por'] = reportadoPor || '';

  const fila = columnas.map((c) => porColumna[c] ?? '');
  const sheets = getClient();
  await sheets.spreadsheets.values.append({
    spreadsheetId: id,
    range: `'${tab}'!A1`,
    valueInputOption: 'USER_ENTERED',
    insertDataOption: 'INSERT_ROWS',
    requestBody: { values: [fila] },
  });
}

// Lee toda la hoja y la regresa como lista de objetos {columna: valor}, usando la
// primera fila como encabezados (igual que el nodo "Leer historial" / "Leer Actividades Diarias").
async function leerHoja(tabla) {
  const { id, tab } = configDeTabla(tabla);
  const sheets = getClient();
  const { data } = await sheets.spreadsheets.values.get({
    spreadsheetId: id,
    range: `'${tab}'`,
  });
  const filas = data.values || [];
  if (filas.length === 0) return [];
  const [encabezados, ...resto] = filas;
  return resto.map((fila) => {
    const obj = {};
    encabezados.forEach((h, i) => { obj[h] = fila[i] !== undefined ? fila[i] : ''; });
    return obj;
  });
}

async function leerActividadesDiarias() {
  return leerHoja('actividades_diarias');
}

module.exports = {
  guardarFila,
  leerHoja,
  leerActividadesDiarias,
  configDeTabla,
};
