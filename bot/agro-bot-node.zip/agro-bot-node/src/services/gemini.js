const axios = require('axios');
const config = require('../config');
const { construirPromptTexto, construirPromptAudio } = require('../prompt');

const GEMINI_URL = () =>
  `https://generativelanguage.googleapis.com/v1beta/models/${config.gemini.model}:generateContent`;

// Nota: las API keys nuevas de Google AI Studio empiezan con "AQ." (en vez de "AIzaSy...")
// y no funcionan bien como query param (?key=...). Por eso se manda como header,
// igual que se configuro en el flujo de n8n (httpHeaderAuth con "x-goog-api-key").
function headers() {
  return {
    'Content-Type': 'application/json',
    'x-goog-api-key': config.gemini.apiKey,
  };
}

async function llamarGemini(parts) {
  const body = { contents: [{ parts }] };
  const { data } = await axios.post(GEMINI_URL(), body, { headers: headers() });
  const raw = data?.candidates?.[0]?.content?.parts?.[0]?.text || '{}';
  return parsearRespuesta(raw);
}

// Misma logica que el nodo "Parsear respuesta Gemini": limpia fences de markdown
// y si el JSON viene invalido, cae en un resultado "no_identificada" en vez de tronar.
function parsearRespuesta(raw) {
  const cleaned = raw.replace(/```json/g, '').replace(/```/g, '').trim();
  let data;
  try {
    data = JSON.parse(cleaned);
  } catch (e) {
    data = { tabla: 'no_identificada', confianza: 'baja', texto_transcrito: raw, campos: {} };
  }
  return {
    tabla: data.tabla || 'no_identificada',
    confianza: data.confianza || 'baja',
    texto_transcrito: data.texto_transcrito || '',
    campos: data.campos || {},
  };
}

async function clasificarTexto(textoBody) {
  const prompt = construirPromptTexto(textoBody);
  return llamarGemini([{ text: prompt }]);
}

async function clasificarAudio(audioBase64, mimeType) {
  const prompt = construirPromptAudio();
  return llamarGemini([
    { text: prompt },
    { inline_data: { mime_type: mimeType || 'audio/ogg', data: audioBase64 } },
  ]);
}

module.exports = { clasificarTexto, clasificarAudio };
