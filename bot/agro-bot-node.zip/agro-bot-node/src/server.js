const express = require('express');
const config = require('./config');
const { programarResumenDiario, ejecutarResumenDiario } = require('./cron/resumenDiario');

const botWebRoute = require('./routes/botWeb');
const mensajeRoute = require('./routes/mensaje');
const guardarRoute = require('./routes/guardar');
const historialRoute = require('./routes/historial');
const whatsappWebhookRoute = require('./routes/whatsappWebhook');

const app = express();

// Limite alto porque el audio grabado en el navegador llega como base64 dentro del JSON.
app.use(express.json({ limit: '25mb' }));

app.use(botWebRoute);
app.use(mensajeRoute);
app.use(guardarRoute);
app.use(historialRoute);
app.use(whatsappWebhookRoute);

app.get('/', (req, res) => res.redirect('/bot-web'));

// Endpoint manual para probar el resumen diario sin esperar al cron (solo para el prototipo).
app.post('/probar-resumen-diario', async (req, res) => {
  try {
    await ejecutarResumenDiario();
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.listen(config.port, () => {
  console.log(`Agro PYME bot corriendo en http://localhost:${config.port}/bot-web`);
  programarResumenDiario();
});
