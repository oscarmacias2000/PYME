const express = require('express');
const path = require('path');

const router = express.Router();

// Rama 1: GET /bot-web -> sirve la pagina HTML (equivalente a "Webhook - Pagina del bot (GET)").
router.get('/bot-web', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

module.exports = router;
