const express = require('express');
const config = require('../config');
const { clasificarMensaje } = require('../lib/clasificar');
const { guardarRegistro } = require('../lib/guardarRegistro');
const whatsapp = require('../services/whatsapp');

const router = express.Router();

// Rama 5: GET /whatsapp-agro -> handshake de verificacion que pide Meta al configurar
// el webhook (equivalente a "Webhook - Verificacion Meta (GET)" -> "Token valido?").
router.get('/whatsapp-agro', (req, res) => {
  const modo = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (modo === 'subscribe' && token === config.whatsapp.verifyToken) {
    res.status(200).send(challenge);
  } else {
    res.status(403).send('Token invalido');
  }
});

// Rama 6: POST /whatsapp-agro -> mensajes reales de WhatsApp.
// A diferencia del bot web, aqui NO se pide confirmacion: se clasifica y se guarda
// directo, y la respuesta se manda de vuelta por WhatsApp (equivalente a
// "Webhook - Mensajes WhatsApp (POST)" -> "Extraer mensaje WhatsApp" -> ... -> "Es Reporte de Campo?").
router.post('/whatsapp-agro', async (req, res) => {
  // Meta espera un 200 rapido; el procesamiento real no debe bloquear la respuesta.
  res.sendStatus(200);

  try {
    const msg = req.body?.entry?.[0]?.changes?.[0]?.value?.messages?.[0];
    const metadata = req.body?.entry?.[0]?.changes?.[0]?.value?.metadata;
    if (!msg) return; // Puede ser un evento de "status" (entregado/leido), no un mensaje.

    const from = msg.from;
    const tipo = msg.type;
    const textoBody = msg.text?.body || '';
    const audioId = msg.audio?.id || '';
    const phoneNumberId = metadata?.phone_number_id;

    let audioBase64 = '';
    let mimeType = '';
    if (tipo === 'audio' && audioId) {
      const mediaUrl = await whatsapp.obtenerUrlAudio(audioId);
      const descarga = await whatsapp.descargarAudioBase64(mediaUrl);
      audioBase64 = descarga.audioBase64;
      mimeType = descarga.mimeType;
    }

    const clasificado = await clasificarMensaje({ tipo, textoBody, audioBase64, mimeType });

    await guardarRegistro({
      tabla: clasificado.tabla,
      campos: clasificado.campos,
      reportadoPor: 'WhatsApp ' + (from || ''),
      textoTranscrito: clasificado.texto_transcrito,
      canal: 'whatsapp',
      whatsappFrom: from,
      whatsappPhoneNumberId: phoneNumberId,
    });
  } catch (e) {
    console.error('Error procesando mensaje de WhatsApp:', e.response?.data || e.message);
  }
});

module.exports = router;
