const express = require('express');
const { clasificarMensaje } = require('../lib/clasificar');

const router = express.Router();

// Rama 2: POST /bot-web-mensaje -> clasifica con Gemini y regresa el preview,
// SIN guardar todavia (equivalente a "Webhook - Mensaje del bot (POST)" -> ... -> "Responder Preview").
router.post('/bot-web-mensaje', async (req, res) => {
  try {
    const { tipo, texto, audio_base64: audioBase64, mime_type: mimeType } = req.body || {};
    const resultado = await clasificarMensaje({
      tipo,
      textoBody: texto,
      audioBase64,
      mimeType,
    });
    res.json({
      ok: true,
      tabla: resultado.tabla,
      confianza: resultado.confianza,
      texto_transcrito: resultado.texto_transcrito,
      campos: resultado.campos,
    });
  } catch (e) {
    console.error('Error clasificando mensaje:', e.response?.data || e.message);
    res.status(200).json({ ok: false, mensaje: 'No se pudo procesar el mensaje con la IA.' });
  }
});

module.exports = router;
