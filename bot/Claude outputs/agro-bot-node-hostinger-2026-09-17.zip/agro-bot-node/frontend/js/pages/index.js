// Logica de la pagina principal del bot (antes vivia inline en public/index.html).
// Se mueve tal cual a un modulo para poder empaquetarla con Webpack + Babel -- el
// comportamiento es identico al de antes, nada mas se movio de lugar.

import { initToggleTema } from '../tema.js';
initToggleTema('btnTema');

const baseUrl = window.location.origin;
const mensajeUrl = baseUrl + '/bot-web-mensaje';
const guardarUrl = baseUrl + '/bot-web-guardar';
const historialUrl = baseUrl + '/bot-web-historial';

// --- Perfil / sesion ---
(async () => {
  try {
    const res = await fetch('/perfil');
    if (res.status === 401) { window.location.href = '/login'; return; }
    const data = await res.json();
    if (data.ok) {
      document.getElementById('nombrePerfil').textContent = data.usuario;
      document.getElementById('avatarPerfil').textContent = (data.usuario || '?').charAt(0).toUpperCase();
    }
  } catch (e) { /* si falla, se queda el "..." -- no es critico para usar la pagina */
  } finally {
    // Quita el splash de carga (logo + skeleton) una vez que ya sabemos si hay sesion
    // o no -- si nos vamos a /login la pagina va a navegar de todos modos.
    const splash = document.getElementById('splashCarga');
    if (splash) {
      splash.style.opacity = '0';
      setTimeout(() => splash.remove(), 250);
    }
  }
})();

document.getElementById('btnPerfil').addEventListener('click', () => {
  document.getElementById('menuPerfil').hidden = !document.getElementById('menuPerfil').hidden;
  document.getElementById('menuDocumentos').hidden = true;
});

// --- Documentos: Excel/PDF de tus Google Sheets (ver routes/botWeb.js -> GET /documentos) ---
async function cargarDocumentos() {
  const cont = document.getElementById('listaDocumentos');
  try {
    const res = await fetch('/documentos');
    const data = await res.json();
    if (!data.ok || !data.documentos || !data.documentos.length) {
      cont.innerHTML = '<p class="text-xs text-stone-400 px-2">No hay documentos configurados.</p>';
      return;
    }
    cont.innerHTML = data.documentos.map((doc) => `
      <div class="px-2 py-1.5">
        <p class="text-xs font-semibold text-stone-700 mb-1.5">${doc.nombre}</p>
        <div class="flex gap-1">
          <a href="${doc.ver}" target="_blank" rel="noopener" class="flex-1 flex items-center justify-center gap-1 bg-stone-50 hover:bg-stone-100 border border-stone-200 rounded-full py-1.5 text-xs transition">
            <svg class="w-3.5 h-3.5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8Z"/><circle cx="12" cy="12" r="3"/></svg>
            Ver
          </a>
          <a href="${doc.excel}" target="_blank" rel="noopener" class="flex-1 flex items-center justify-center gap-1 bg-green-50 hover:bg-green-100 border border-green-200 text-green-700 rounded-full py-1.5 text-xs transition">
            <img src="/img/excel.webp" alt="" class="w-3.5 h-3.5 shrink-0">
            Excel
          </a>
          <a href="${doc.pdf}" target="_blank" rel="noopener" class="flex-1 flex items-center justify-center gap-1 bg-red-50 hover:bg-red-100 border border-red-200 text-red-700 rounded-full py-1.5 text-xs transition">
            <img src="/img/pdf.svg" alt="" class="w-3.5 h-3.5 shrink-0">
            PDF
          </a>
        </div>
      </div>
    `).join('');
  } catch (e) {
    cont.innerHTML = '<p class="text-xs text-red-500 px-2">Error: ' + e.message + '</p>';
  }
}
cargarDocumentos();

document.getElementById('btnDocumentos').addEventListener('click', () => {
  document.getElementById('menuDocumentos').hidden = !document.getElementById('menuDocumentos').hidden;
  document.getElementById('menuPerfil').hidden = true;
});
document.addEventListener('click', (e) => {
  if (!e.target.closest('#btnDocumentos') && !e.target.closest('#menuDocumentos')) {
    document.getElementById('menuDocumentos').hidden = true;
  }
});

// --- Foto de perfil (unica y compartida, ver comentario en routes/auth.js) ---
const avatarPerfil = document.getElementById('avatarPerfil');
const avatarFoto = document.getElementById('avatarFoto');
// Si /img/perfil.jpg no existe todavia (nadie ha subido foto), el <img> tira error y se
// queda el circulo con la inicial -- si carga bien, se muestra la foto en su lugar.
avatarFoto.addEventListener('load', () => { avatarFoto.hidden = false; avatarPerfil.hidden = true; });
avatarFoto.addEventListener('error', () => { avatarFoto.hidden = true; avatarPerfil.hidden = false; });

// Recorta la imagen a cuadro (desde el centro) y la comprime a JPEG en el navegador --
// asi no importa si suben un PNG/HEIC/lo-que-sea gigante, siempre se manda liviano y en
// un formato que el servidor puede guardar tal cual (ver POST /perfil-foto).
function recortarYComprimirFoto(file) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(url);
      const TAMANO = 256;
      const canvas = document.createElement('canvas');
      canvas.width = TAMANO;
      canvas.height = TAMANO;
      const ctx = canvas.getContext('2d');
      const lado = Math.min(img.width, img.height);
      const sx = (img.width - lado) / 2;
      const sy = (img.height - lado) / 2;
      ctx.drawImage(img, sx, sy, lado, lado, 0, 0, TAMANO, TAMANO);
      resolve(canvas.toDataURL('image/jpeg', 0.85));
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('No se pudo leer la imagen.')); };
    img.src = url;
  });
}

const inputFotoPerfil = document.getElementById('inputFotoPerfil');
document.getElementById('btnCambiarFoto').addEventListener('click', () => {
  document.getElementById('menuPerfil').hidden = true;
  inputFotoPerfil.click();
});
inputFotoPerfil.addEventListener('change', async (e) => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  try {
    const dataUrl = await recortarYComprimirFoto(file);
    const res = await fetch('/perfil-foto', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ foto_base64: dataUrl.split(',')[1] }),
    });
    const data = await res.json();
    if (!data.ok) { alert(data.mensaje || 'No se pudo guardar la foto.'); return; }
    avatarFoto.src = dataUrl;
    avatarFoto.hidden = false;
    avatarPerfil.hidden = true;
  } catch (err) {
    alert('No se pudo procesar la imagen: ' + err.message);
  }
});
document.addEventListener('click', (e) => {
  if (!e.target.closest('#btnPerfil') && !e.target.closest('#menuPerfil')) {
    document.getElementById('menuPerfil').hidden = true;
  }
});
document.getElementById('btnCerrarSesion').addEventListener('click', async () => {
  try { await fetch('/logout', { method: 'POST' }); } catch (e) {}
  window.location.href = '/login';
});

const NOMBRES_TABLA = {
  reporte_campo: 'Rendimiento Diario Jornal',
  actividades_diarias: 'Actividades Diarias',
  maquinaria: 'Maquinaria',
  insumos: 'Insumos',
  catalogos: 'Catálogos',
  resumen_semanal: 'Resumen Semanal',
  resumen_dia: 'Resumen del Día',
};
// Estas son de solo lectura -- no tienen "campos" que llenar para agregar un
// registro nuevo, solo se pueden preguntar/consultar (ver actualizarDisponibilidadModo).
const TABLAS_SOLO_LECTURA = ['catalogos', 'resumen_semanal', 'resumen_dia'];

const CAMPOS_REPORTE_CAMPO = [
  ['Fecha','Fecha'], ['Actividad','Actividad'], ['Ubicacion','Ubicacion'], ['Huerta','Huerta'],
  ['Responsable','Responsable'], ['NumeroDePersonas','N de personas'], ['CantidadRealizada','Cantidad realizada'],
  ['UnidadDeMedida','Unidad de medida'], ['MetaDeRendimiento','Meta de rendimiento'], ['Incidencia','Incidencia (Si/No)'],
  ['MotivoDeIncidencia','Motivo de incidencia'], ['Observaciones','Observaciones']
];
const CAMPOS_ACTIVIDADES = [
  ['Fecha','Fecha'], ['Campo','Campo'], ['Lote','Lote'], ['Actividad','Actividad'], ['Responsable','Responsable'],
  ['NumeroJornaleros','N de jornaleros'], ['ProcedenciaCuadrilla','Procedencia / cuadrilla'],
  ['RecursosMaquinaria','Recursos / maquinaria'], ['CostoPorJornal','Costo por jornal'], ['NominaTotal','Nomina total'],
  ['Observaciones','Observaciones']
];
const CAMPOS_MAQUINARIA = [
  ['Fecha','Fecha'], ['Equipo','Equipo'], ['Implemento','Implemento'], ['TipoCombustible','Tipo de combustible'],
  ['Actividad','Actividad'], ['Ubicacion','Ubicacion'], ['Huerta','Huerta'], ['Responsable','Responsable (operador)'],
  ['Litros','Litros'], ['Horas','Horas'], ['CostoTotal','Costo total'], ['AvanceRendimiento','Avance (ha)'],
  ['Observaciones','Observaciones']
];
const CAMPOS_INSUMOS = [
  ['Fecha','Fecha'], ['RecursoInsumo','Recurso / insumo'], ['Cantidad','Cantidad'], ['UnidadDeMedida','Unidad de medida'],
  ['MotivoDeUso','Motivo de uso'], ['Actividad','Actividad'], ['Huerta','Huerta'], ['CostoPorUnidad','Costo por unidad'],
  ['CostoTotal','Costo total'], ['Responsable','Responsable']
];

const CAMPOS_POR_TABLA = {
  reporte_campo: CAMPOS_REPORTE_CAMPO,
  actividades_diarias: CAMPOS_ACTIVIDADES,
  maquinaria: CAMPOS_MAQUINARIA,
  insumos: CAMPOS_INSUMOS,
};

const estado = document.getElementById('estado');
const capturaCard = document.getElementById('captura');
const previewCard = document.getElementById('preview');
const camposDiv = document.getElementById('campos');
const previewTablaTexto = document.getElementById('previewTablaTexto');
const nombreInput = document.getElementById('nombre');
const tituloMensaje = document.getElementById('tituloMensaje');
const textoInput = document.getElementById('texto');
const btnTexto = document.getElementById('btnTexto');

try {
  const guardado = localStorage.getItem('agro_bot_nombre');
  if (guardado) nombreInput.value = guardado;
} catch (e) {}
nombreInput.addEventListener('change', () => {
  try { localStorage.setItem('agro_bot_nombre', nombreInput.value); } catch (e) {}
});

function mostrar(clase, texto) {
  estado.hidden = false;
  const base = 'mt-4 rounded-2xl px-4 py-3 text-sm whitespace-pre-wrap flex items-center gap-2';
  const estilos = {
    ok: base + ' bg-green-50 text-green-800 border border-green-200',
    err: base + ' bg-red-50 text-red-700 border border-red-200',
    wait: base + ' bg-amber-50 text-amber-800 border border-amber-200',
  };
  estado.className = estilos[clase] || base;
  estado.innerHTML = '';
  if (clase === 'wait') {
    const img = document.createElement('img');
    img.src = '/img/mark.png';
    img.alt = '';
    img.className = 'w-4 h-4 logo-pulse shrink-0';
    estado.appendChild(img);
  }
  const span = document.createElement('span');
  span.textContent = texto;
  estado.appendChild(span);
}
function ocultarEstado() { estado.hidden = true; }

let camposActuales = {};
let textoTranscritoActual = '';
let tablaSeleccionada = 'actividades_diarias';
let modoSeleccionado = 'agregar';

const btnTablaDesplegable = document.getElementById('btnTablaDesplegable');
const listaTablas = document.getElementById('listaTablas');
const tablaSeleccionadaTexto = document.getElementById('tablaSeleccionadaTexto');
const notaSoloLectura = document.getElementById('notaSoloLectura');

function actualizarTablaSeleccionada() {
  tablaSeleccionadaTexto.textContent = NOMBRES_TABLA[tablaSeleccionada] || tablaSeleccionada;
  document.querySelectorAll('.opcionTabla').forEach((btn) => {
    btn.classList.toggle('bg-stone-50', btn.dataset.tabla === tablaSeleccionada);
  });
}

// Catalogos, Resumen Semanal y Resumen del Dia son de solo lectura -- si se eligen, se
// apaga el modo "Agregar Datos" y se fuerza "Leer / Preguntar" (no tiene sentido
// "agregar" un dato a una lista de catalogos o a un resumen que se calcula solo).
function actualizarDisponibilidadModo() {
  const soloLectura = TABLAS_SOLO_LECTURA.includes(tablaSeleccionada);
  const btnAgregar = document.querySelector('#pillsModo button[data-modo="agregar"]');
  btnAgregar.disabled = soloLectura;
  btnAgregar.classList.toggle('opacity-30', soloLectura);
  btnAgregar.classList.toggle('cursor-not-allowed', soloLectura);
  notaSoloLectura.hidden = !soloLectura;
  if (soloLectura && modoSeleccionado !== 'leer') {
    modoSeleccionado = 'leer';
  }
  actualizarPillsModo();
}

function actualizarPillsModo() {
  document.querySelectorAll('#pillsModo .pill').forEach((btn) => {
    btn.classList.toggle('activa', btn.dataset.modo === modoSeleccionado);
  });
  const esLeer = modoSeleccionado === 'leer';
  tituloMensaje.textContent = esLeer ? '3. Escribe o pregunta en voz' : '3. Escribe o graba tu mensaje';
  textoInput.placeholder = esLeer
    ? 'Ej: ¿Que actividades se hicieron el 31 de agosto?'
    : 'Ej: Hoy en Pedregoza cortamos 40 arboles de mango con 6 jornaleros, meta eran 50...';
  btnTexto.title = esLeer ? 'Preguntar' : 'Enviar texto';
}

btnTablaDesplegable.addEventListener('click', () => {
  listaTablas.hidden = !listaTablas.hidden;
});
listaTablas.addEventListener('click', (e) => {
  const btn = e.target.closest('button[data-tabla]');
  if (!btn) return;
  tablaSeleccionada = btn.dataset.tabla;
  actualizarTablaSeleccionada();
  actualizarDisponibilidadModo();
  listaTablas.hidden = true;
});
document.addEventListener('click', (e) => {
  if (!e.target.closest('#btnTablaDesplegable') && !e.target.closest('#listaTablas')) {
    listaTablas.hidden = true;
  }
});
document.getElementById('pillsModo').addEventListener('click', (e) => {
  const btn = e.target.closest('button[data-modo]');
  if (!btn || btn.disabled) return;
  modoSeleccionado = btn.dataset.modo;
  actualizarPillsModo();
});
actualizarTablaSeleccionada();
actualizarDisponibilidadModo();

function renderCampos(tabla) {
  const lista = CAMPOS_POR_TABLA[tabla] || CAMPOS_ACTIVIDADES;
  camposDiv.innerHTML = '';
  lista.forEach(([clave, etiqueta]) => {
    const wrap = document.createElement('div');
    const label = document.createElement('label');
    label.textContent = etiqueta;
    label.className = 'block text-xs font-semibold text-stone-500 uppercase tracking-wide mb-1';
    const input = document.createElement('input');
    input.type = 'text';
    input.dataset.clave = clave;
    input.className = 'w-full border border-stone-200 rounded-full px-4 py-2.5 text-sm bg-stone-50 focus:outline-none focus:ring-2 focus:ring-green-500 focus:bg-white';
    input.value = (camposActuales[clave] !== undefined && camposActuales[clave] !== null) ? camposActuales[clave] : '';
    wrap.appendChild(label);
    wrap.appendChild(input);
    camposDiv.appendChild(wrap);
  });
}

async function enviarMensaje(payload) {
  mostrar('wait', 'Procesando con IA, un momento...');
  try {
    const res = await fetch(mensajeUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...payload, modo: modoSeleccionado, tabla: tablaSeleccionada })
    });
    const data = await res.json();
    if (!data.ok) { mostrar('err', data.mensaje || 'No se pudo procesar.'); return; }

    // Modo "leer": la respuesta es texto directo, no se abre el formulario de guardar.
    if (data.modo === 'consulta') {
      mostrar('ok', data.respuesta || 'Sin respuesta.');
      return;
    }

    camposActuales = data.campos || {};
    textoTranscritoActual = data.texto_transcrito || '';
    const tablaDetectada = CAMPOS_POR_TABLA[data.tabla] ? data.tabla : tablaSeleccionada;
    tablaSeleccionada = tablaDetectada;
    actualizarTablaSeleccionada();
    previewTablaTexto.textContent = NOMBRES_TABLA[tablaDetectada] || tablaDetectada;
    renderCampos(tablaDetectada);
    capturaCard.hidden = true;
    previewCard.hidden = false;
    ocultarEstado();
    mostrarTabSidebar('acciones');
    abrirSidebar();
    if (data.tabla === 'no_identificada') {
      mostrar('wait', 'No se identifico bien el mensaje, revisa/completa los campos.');
    }
  } catch (e) {
    mostrar('err', 'No se pudo enviar: ' + e.message);
  }
}

// Estilo ChatGPT/Claude: el textarea crece solo conforme escribes (hasta un maximo).
function ajustarAlturaTexto() {
  textoInput.style.height = 'auto';
  textoInput.style.height = Math.min(textoInput.scrollHeight, 160) + 'px';
}
textoInput.addEventListener('input', ajustarAlturaTexto);

btnTexto.addEventListener('click', () => {
  const texto = textoInput.value.trim();
  if (!texto) { mostrar('err', 'Escribe algo primero.'); return; }
  enviarMensaje({ tipo: 'texto', texto });
  textoInput.value = '';
  ajustarAlturaTexto();
});

const CLASE_BTN_AUDIO_NORMAL = 'w-10 h-10 shrink-0 rounded-full flex items-center justify-center bg-white border border-stone-300 hover:bg-stone-100 text-stone-600 transition';
const CLASE_BTN_AUDIO_GRABANDO = 'w-10 h-10 shrink-0 rounded-full flex items-center justify-center bg-red-600 hover:bg-red-700 text-white transition';
const ICONO_MIC = '<svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>';
const ICONO_STOP = '<svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>';

function actualizarBtnAudio(grabando) {
  btnAudio.className = grabando ? CLASE_BTN_AUDIO_GRABANDO : CLASE_BTN_AUDIO_NORMAL;
  btnAudio.innerHTML = grabando ? ICONO_STOP : ICONO_MIC;
  btnAudio.title = grabando ? 'Detener y enviar' : 'Grabar audio';
}

let mediaRecorder, chunks = [];
const btnAudio = document.getElementById('btnAudio');
btnAudio.addEventListener('click', async () => {
  if (mediaRecorder && mediaRecorder.state === 'recording') {
    mediaRecorder.stop();
    return;
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    chunks = [];
    mediaRecorder = new MediaRecorder(stream);
    mediaRecorder.ondataavailable = e => chunks.push(e.data);
    mediaRecorder.onstop = () => {
      stream.getTracks().forEach(t => t.stop());
      actualizarBtnAudio(false);
      const blob = new Blob(chunks, { type: mediaRecorder.mimeType || 'audio/webm' });
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result.split(',')[1];
        enviarMensaje({ tipo: 'audio', audio_base64: base64, mime_type: blob.type || 'audio/webm' });
      };
      reader.readAsDataURL(blob);
    };
    mediaRecorder.start();
    actualizarBtnAudio(true);
    mostrar('wait', 'Grabando... presiona de nuevo para enviar.');
  } catch (e) {
    mostrar('err', 'No se pudo acceder al microfono: ' + e.message);
  }
});

document.getElementById('btnCancelar').addEventListener('click', () => {
  previewCard.hidden = true;
  capturaCard.hidden = false;
  ocultarEstado();
});

document.getElementById('btnGuardar').addEventListener('click', async () => {
  const inputs = camposDiv.querySelectorAll('input');
  const camposEditados = {};
  inputs.forEach(inp => { camposEditados[inp.dataset.clave] = inp.value; });
  mostrar('wait', 'Guardando...');
  try {
    const res = await fetch(guardarUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        tabla: tablaSeleccionada,
        campos: camposEditados,
        reportado_por: nombreInput.value || '',
        texto_transcrito: textoTranscritoActual
      })
    });
    const data = await res.json();
    previewCard.hidden = true;
    capturaCard.hidden = false;
    mostrar(data.ok === false ? 'err' : 'ok', data.mensaje || 'Guardado.');
  } catch (e) {
    mostrar('err', 'No se pudo guardar: ' + e.message);
  }
});

function renderHistorial(registros) {
  const cont = document.getElementById('histResultado');
  if (!registros || registros.length === 0) {
    cont.innerHTML = '<p class="text-xs text-stone-400">Sin registros.</p>';
    return;
  }
  cont.innerHTML = registros.map(r => {
    const partes = Object.entries(r).filter(([k,v]) => v !== '' && v !== null && v !== undefined).slice(0, 6);
    return '<div class="border border-stone-100 rounded-2xl px-3 py-2 text-xs text-stone-600 bg-stone-50">' +
      partes.map(([k,v]) => '<b class="text-stone-800">' + k + ':</b> ' + v).join(' &nbsp;|&nbsp; ') + '</div>';
  }).join('');
}

let tablaHistorialActual = null;
const btnActualizarHistorial = document.getElementById('btnActualizarHistorial');

async function verHistorial(tabla) {
  tablaHistorialActual = tabla;
  if (btnActualizarHistorial) btnActualizarHistorial.disabled = false;
  const cont = document.getElementById('histResultado');
  // Placeholder tipo "skeleton" (mismo shimmer que el splash de carga) mientras llega la
  // respuesta, en vez de un simple texto "Cargando...".
  cont.innerHTML = `
    <div class="border border-stone-100 rounded-2xl px-3 py-2.5 bg-stone-50 space-y-1.5">
      <div class="skeleton-line w-3/4"></div>
      <div class="skeleton-line w-1/2"></div>
    </div>
    <div class="border border-stone-100 rounded-2xl px-3 py-2.5 bg-stone-50 space-y-1.5">
      <div class="skeleton-line w-2/3"></div>
      <div class="skeleton-line w-1/3"></div>
    </div>
  `;
  try {
    const res = await fetch(historialUrl + '?tabla=' + tabla);
    const data = await res.json();
    renderHistorial(data.registros);
  } catch (e) {
    cont.innerHTML = '<p class="text-xs text-red-500">Error: ' + e.message + '</p>';
  }
}

document.querySelectorAll('.histBtn').forEach((btn) => {
  btn.addEventListener('click', () => verHistorial(btn.dataset.tabla));
});
if (btnActualizarHistorial) {
  btnActualizarHistorial.addEventListener('click', () => {
    if (tablaHistorialActual) verHistorial(tablaHistorialActual);
  });
}

// --- Acciones rapidas: copiar el enlace del bot al portapapeles ---
const btnCopiarEnlace = document.getElementById('btnCopiarEnlace');
if (btnCopiarEnlace) {
  const textoOriginalCopiar = btnCopiarEnlace.innerHTML;
  btnCopiarEnlace.addEventListener('click', async () => {
    const enlace = window.location.origin + '/bot-web';
    try {
      await navigator.clipboard.writeText(enlace);
      btnCopiarEnlace.textContent = '✅ Enlace copiado';
    } catch (e) {
      btnCopiarEnlace.textContent = 'No se pudo copiar -- copialo tu: ' + enlace;
    }
    setTimeout(() => { btnCopiarEnlace.innerHTML = textoOriginalCopiar; }, 2000);
  });
}

async function enviarResumenAhora(ruta, boton, nombre) {
  const cont = document.getElementById('correoResultado');
  const textoOriginal = boton.textContent;
  boton.disabled = true;
  boton.textContent = 'Enviando...';
  cont.innerHTML = '<p>Armando y mandando el ' + nombre + ', un momento...</p>';
  try {
    const res = await fetch(baseUrl + ruta, { method: 'POST' });
    const data = await res.json();
    cont.innerHTML = data.ok
      ? '<p class="text-green-700">Listo, se mando el ' + nombre + ' al correo.</p>'
      : '<p class="text-red-600">No se pudo mandar: ' + (data.error || 'error desconocido') + '</p>';
  } catch (e) {
    cont.innerHTML = '<p class="text-red-600">Error: ' + e.message + '</p>';
  } finally {
    boton.disabled = false;
    boton.textContent = textoOriginal;
  }
}

document.getElementById('btnEnviarResumenDiario').addEventListener('click', (e) =>
  enviarResumenAhora('/probar-resumen-diario', e.target, 'resumen diario'));
document.getElementById('btnEnviarResumenSemanal').addEventListener('click', (e) =>
  enviarResumenAhora('/probar-resumen-semanal', e.target, 'resumen semanal'));

async function enviarTabPorCorreo(tab, boton, etiqueta) {
  const cont = document.getElementById('correoResultado');
  const textoOriginal = boton.textContent;
  boton.disabled = true;
  boton.textContent = 'Enviando...';
  cont.innerHTML = '<p>Mandando el documento (pestaña ' + etiqueta + '), un momento...</p>';
  try {
    const res = await fetch(baseUrl + '/enviar-tab-correo', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tab }),
    });
    const data = await res.json();
    cont.innerHTML = data.ok
      ? '<p class="text-green-700">Listo, se mando el documento (pestaña ' + etiqueta + ') al correo.</p>'
      : '<p class="text-red-600">No se pudo mandar: ' + (data.error || 'error desconocido') + '</p>';
  } catch (e) {
    cont.innerHTML = '<p class="text-red-600">Error: ' + e.message + '</p>';
  } finally {
    boton.disabled = false;
    boton.textContent = textoOriginal;
  }
}

document.querySelectorAll('.tabCorreoBtn').forEach((btn) => {
  btn.addEventListener('click', () => enviarTabPorCorreo(btn.dataset.tab, btn, btn.textContent));
});

// --- Sidebar: abrir/cerrar en movil ---
const sidebar = document.getElementById('sidebar');
const sidebarBackdrop = document.getElementById('sidebarBackdrop');

function abrirSidebar() {
  sidebar.classList.add('abierto');
  sidebarBackdrop.classList.remove('opacity-0', 'pointer-events-none');
}
function cerrarSidebar() {
  sidebar.classList.remove('abierto');
  sidebarBackdrop.classList.add('opacity-0', 'pointer-events-none');
}
document.getElementById('btnAbrirSidebar').addEventListener('click', abrirSidebar);
document.getElementById('btnCerrarSidebar').addEventListener('click', cerrarSidebar);
sidebarBackdrop.addEventListener('click', cerrarSidebar);

// --- Sidebar: pestañas Historial / Acciones / Actividad en vivo ---
const tabHistorialBtn = document.getElementById('tabHistorialBtn');
const tabAccionesBtn = document.getElementById('tabAccionesBtn');
const tabNoticiasBtn = document.getElementById('tabNoticiasBtn');
const tabActividadBtn = document.getElementById('tabActividadBtn');
const panelHistorial = document.getElementById('panelHistorial');
const panelAcciones = document.getElementById('panelAcciones');
const panelNoticias = document.getElementById('panelNoticias');
const panelActividad = document.getElementById('panelActividad');

function mostrarTabSidebar(tab) {
  tabHistorialBtn.classList.toggle('activa', tab === 'historial');
  tabAccionesBtn.classList.toggle('activa', tab === 'acciones');
  tabNoticiasBtn.classList.toggle('activa', tab === 'noticias');
  tabActividadBtn.classList.toggle('activa', tab === 'actividad');
  panelHistorial.hidden = tab !== 'historial';
  panelAcciones.hidden = tab !== 'acciones';
  panelNoticias.hidden = tab !== 'noticias';
  panelActividad.hidden = tab !== 'actividad';
}
tabHistorialBtn.addEventListener('click', () => mostrarTabSidebar('historial'));
tabAccionesBtn.addEventListener('click', () => mostrarTabSidebar('acciones'));
tabNoticiasBtn.addEventListener('click', () => mostrarTabSidebar('noticias'));
tabActividadBtn.addEventListener('click', () => mostrarTabSidebar('actividad'));

// --- Sidebar: Actividad en vivo (misma conexion Socket.io que /actividad-en-vivo) ---
const puntoEstadoSidebar = document.getElementById('puntoEstadoSidebar');
const textoEstadoSidebar = document.getElementById('textoEstadoSidebar');

const socket = io();
socket.on('connect', () => {
  puntoEstadoSidebar.className = 'w-2 h-2 rounded-full bg-green-500 shrink-0';
  textoEstadoSidebar.textContent = 'Conectado';
});
socket.on('disconnect', () => {
  puntoEstadoSidebar.className = 'w-2 h-2 rounded-full bg-red-500 shrink-0';
  textoEstadoSidebar.textContent = 'Desconectado';
});
socket.on('connect_error', (err) => {
  puntoEstadoSidebar.className = 'w-2 h-2 rounded-full bg-amber-500 shrink-0';
  textoEstadoSidebar.textContent = 'Error de conexion: ' + err.message;
});
// Nota: por ahora solo se ve el estado de conexion -- los eventos reales (mensaje
// recibido, clasificando con IA, guardando en Sheets, etc.) se agregan en un siguiente
// paso, emitidos desde el backend con socketService.emitirEvento(...).
