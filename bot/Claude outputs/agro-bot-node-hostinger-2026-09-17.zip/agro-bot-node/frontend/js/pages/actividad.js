// Logica de la pagina "Actividad en vivo" (antes vivia inline en public/actividad.html).

import { initToggleTema } from '../tema.js';
initToggleTema('btnTema');

const puntoEstado = document.getElementById('puntoEstado');
const textoEstado = document.getElementById('textoEstado');

const socket = io();

socket.on('connect', () => {
  puntoEstado.className = 'w-2.5 h-2.5 rounded-full bg-green-500';
  textoEstado.textContent = 'Conectado ✓';
});
socket.on('disconnect', () => {
  puntoEstado.className = 'w-2.5 h-2.5 rounded-full bg-red-500';
  textoEstado.textContent = 'Desconectado';
});
socket.on('connect_error', (err) => {
  puntoEstado.className = 'w-2.5 h-2.5 rounded-full bg-amber-500';
  textoEstado.textContent = 'Error de conexion: ' + err.message;
});
