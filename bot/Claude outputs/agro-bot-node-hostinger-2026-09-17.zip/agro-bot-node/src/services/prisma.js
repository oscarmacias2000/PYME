// Cliente unico de Prisma compartido en todo el proyecto -- crear una sola instancia
// evita agotar las conexiones a MySQL cuando el servidor recarga codigo (npm run dev
// usa "node --watch", que reinicia el proceso pero conviene mantener el patron por si
// mas adelante se usa algo como nodemon con recarga en caliente).
const { PrismaClient } = require('@prisma/client');

const prisma = global.__prismaClient || new PrismaClient();
if (process.env.NODE_ENV !== 'production') {
  global.__prismaClient = prisma;
}

module.exports = prisma;
