const express = require('express');
const path = require('path');
const config = require('../config');

const router = express.Router();

// Rama 1: GET /bot-web -> sirve la pagina HTML (equivalente a "Webhook - Pagina del bot (GET)").
router.get('/bot-web', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// GET /documentos -> arma los links a los Google Sheets configurados (ver una hoja de
// calculo, o descargarla directo como Excel/PDF) para el menu "Documentos" del header.
// Se arma aqui (y no hardcodeado en index.html) para que siempre use los IDs reales de
// tu .env -- si cambias de hoja de calculo, este menu se actualiza solo.
function linksHoja(id) {
  return {
    ver: `https://docs.google.com/spreadsheets/d/${id}/edit`,
    excel: `https://docs.google.com/spreadsheets/d/${id}/export?format=xlsx`,
    pdf: `https://docs.google.com/spreadsheets/d/${id}/export?format=pdf`,
  };
}
router.get('/documentos', (req, res) => {
  const { reporteCampo, actividadesDiarias } = config.google.sheets;
  const documentos = [];
  if (reporteCampo.id) {
    documentos.push({ nombre: 'Reporte de Campo', ...linksHoja(reporteCampo.id) });
  }
  if (actividadesDiarias.id) {
    documentos.push({ nombre: 'Actividades Diarias', ...linksHoja(actividadesDiarias.id) });
  }
  res.json({ ok: true, documentos });
});

module.exports = router;
